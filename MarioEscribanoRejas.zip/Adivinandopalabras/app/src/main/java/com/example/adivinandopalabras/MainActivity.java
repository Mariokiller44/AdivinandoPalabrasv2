package com.example.adivinandopalabras;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    public String[] palabras = {"Memoria","Inteligencia","Capacidad"};
    public int intentos=5;
    public int posi= (int) Math.floor(Math.random()* palabras.length);
    public String palabraNueva = palabras[posi];
    char [] caracteres =palabraNueva.toCharArray();
    public char [] guiones=new char[caracteres.length];

    public boolean[] comprobar= new boolean[caracteres.length];
    boolean salida=false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iniciarJuego();

    }

    public void iniciarJuego() {

        TextView textoIntentos = (TextView) findViewById(R.id.intentos);
        textoIntentos.setText("Intentos: "+intentos);
        TextView texto = (TextView) findViewById(R.id.palabra);
        llenarGuiones();
        for (int i=0;i<caracteres.length;i++){
            texto.setText(caracteres,i,caracteres.length);
            comprobar[i]=false;
        }
      /*  while(!seguirJugando()){
            jugar();
        }*/
    }

    private void llenarGuiones() {
        for(int i=0;i<guiones.length;i++){
            guiones[i]='_';
        }
    }

   /* private void jugar() {
        for (int i=0;i<caracteres.length;i++){
            if (comprobar[i]==false){
                TextView texto= (TextView) findViewById(R.id.palabra);
                texto.setText(guiones[i]);
            }else{
                char letra = caracteres[i];
                intentos=intentos-1;
                TextView texto = (TextView) findViewById(R.id.palabra);
                texto.setText(letra);
            }
        }
    }*/

    public void obtenerLetra(View v){
        TextView textoRecogida = (TextView) findViewById(R.id.letra);
        if (textoRecogida.getText().length()>1){
            Toast.makeText(this,"Debe introducir una letra",Toast.LENGTH_SHORT).show();
        }else{
            for (int i=0;i<caracteres.length;i++) {
                String letra = textoRecogida.getText().toString();
                if (palabraNueva.contains(letra)){
                    comprobar[i]=true;
                }
            }
        }
    }
    public boolean seguirJugando(){
        if (intentos==0){
            salida=true;
        }
        return salida;
    }

 /*   public void cambioDePalabra(View v){
        Button nuevaP = (Button) findViewById(R.id.nuevo);


    }
*/
}